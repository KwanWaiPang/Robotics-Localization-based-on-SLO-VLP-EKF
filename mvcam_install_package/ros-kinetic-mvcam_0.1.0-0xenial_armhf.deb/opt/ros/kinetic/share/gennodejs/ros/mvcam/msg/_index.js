
"use strict";

let Rect_image1 = require('./Rect_image1.js');
let Rect_image = require('./Rect_image.js');

module.exports = {
  Rect_image1: Rect_image1,
  Rect_image: Rect_image,
};
