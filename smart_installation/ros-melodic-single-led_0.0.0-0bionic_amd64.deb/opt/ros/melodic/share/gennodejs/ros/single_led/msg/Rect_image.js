// Auto-generated. Do not edit!

// (in-package single_led.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Rect_image {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.Img_local_X = null;
      this.Img_local_Y = null;
      this.width = null;
      this.height = null;
      this.image_roi = null;
      this.flag_roi = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('Img_local_X')) {
        this.Img_local_X = initObj.Img_local_X
      }
      else {
        this.Img_local_X = 0.0;
      }
      if (initObj.hasOwnProperty('Img_local_Y')) {
        this.Img_local_Y = initObj.Img_local_Y
      }
      else {
        this.Img_local_Y = 0.0;
      }
      if (initObj.hasOwnProperty('width')) {
        this.width = initObj.width
      }
      else {
        this.width = 0.0;
      }
      if (initObj.hasOwnProperty('height')) {
        this.height = initObj.height
      }
      else {
        this.height = 0.0;
      }
      if (initObj.hasOwnProperty('image_roi')) {
        this.image_roi = initObj.image_roi
      }
      else {
        this.image_roi = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('flag_roi')) {
        this.flag_roi = initObj.flag_roi
      }
      else {
        this.flag_roi = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Rect_image
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [Img_local_X]
    bufferOffset = _serializer.float64(obj.Img_local_X, buffer, bufferOffset);
    // Serialize message field [Img_local_Y]
    bufferOffset = _serializer.float64(obj.Img_local_Y, buffer, bufferOffset);
    // Serialize message field [width]
    bufferOffset = _serializer.float64(obj.width, buffer, bufferOffset);
    // Serialize message field [height]
    bufferOffset = _serializer.float64(obj.height, buffer, bufferOffset);
    // Serialize message field [image_roi]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.image_roi, buffer, bufferOffset);
    // Serialize message field [flag_roi]
    bufferOffset = _serializer.uint8(obj.flag_roi, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Rect_image
    let len;
    let data = new Rect_image(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [Img_local_X]
    data.Img_local_X = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [Img_local_Y]
    data.Img_local_Y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [width]
    data.width = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [height]
    data.height = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [image_roi]
    data.image_roi = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [flag_roi]
    data.flag_roi = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += sensor_msgs.msg.Image.getMessageSize(object.image_roi);
    return length + 33;
  }

  static datatype() {
    // Returns string type for a message object
    return 'single_led/Rect_image';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3cc60990ec2a969cc0c184258dba5f1f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    float64 Img_local_X
    float64 Img_local_Y
    float64 width
    float64 height
    sensor_msgs/Image image_roi
    uint8 flag_roi
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of camera
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Rect_image(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.Img_local_X !== undefined) {
      resolved.Img_local_X = msg.Img_local_X;
    }
    else {
      resolved.Img_local_X = 0.0
    }

    if (msg.Img_local_Y !== undefined) {
      resolved.Img_local_Y = msg.Img_local_Y;
    }
    else {
      resolved.Img_local_Y = 0.0
    }

    if (msg.width !== undefined) {
      resolved.width = msg.width;
    }
    else {
      resolved.width = 0.0
    }

    if (msg.height !== undefined) {
      resolved.height = msg.height;
    }
    else {
      resolved.height = 0.0
    }

    if (msg.image_roi !== undefined) {
      resolved.image_roi = sensor_msgs.msg.Image.Resolve(msg.image_roi)
    }
    else {
      resolved.image_roi = new sensor_msgs.msg.Image()
    }

    if (msg.flag_roi !== undefined) {
      resolved.flag_roi = msg.flag_roi;
    }
    else {
      resolved.flag_roi = 0
    }

    return resolved;
    }
};

module.exports = Rect_image;
