#!/usr/bin/expect
set user "ubuntu"
set ip "192.168.0.106"
set password "ubuntu"
set timeout 20
#opensend a ssh link, the comment must begin at a new line
spawn ssh $user@$ip 
expect {
	"(yes/no)?" { send "yes\r"; exp_continue;}
	"password:" { send "$password\r"; exp_continue;}
	"*@*" { send "ROS_NAMESPACE=tb3_0 roslaunch turtlebot3_bringup turtlebot3_robot.launch multi_robot_name:=\"tb3_0\" set_lidar_frame_id:=\"tb3_0/base_scan\"\r"; }
}
interact


