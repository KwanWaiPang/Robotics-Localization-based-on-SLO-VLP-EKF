#! /bin/bash
#gnome-terminal --window -e 'bash -c "roscore;exec bash"'
###############################################################
gnome-terminal --window -e 'bash -c "expect rb1_launch.sh;exec bash"'
# gnome-terminal --window -e 'bash -c "expect rb1_launch_cam.sh;exec bash"'
###############################################################
gnome-terminal --window -e 'bash -c "expect rb2_launch.sh;exec bash"'
gnome-terminal --window -e 'bash -c "expect rb2_launch_cam.sh;exec bash"'
gnome-terminal --window -e 'bash -c "expect rb3_launch.sh;exec bash"'
###############################################################
sleep 5s
# gnome-terminal --window -e 'bash -c "roslaunch turtlebot3_nps move_base_two.launch;exec bash"'
# gnome-terminal --window -e 'bash -c "roslaunch turtlebot3_nps navigation_two.launch map_file:=$HOME/map/3.yaml;exec bash"'
# gnome-terminal --window -e 'bash -c "roslaunch turtlebot3_nps navigation_two.launch map_file:=$HOME/map/map/ICDC_slam_map_vlp_1000.yaml;exec bash"'
gnome-terminal --window -e 'bash -c "roslaunch multi_turtlebot3_navigation navigation_three.launch map_file:=$HOME/map/map/ICDC_slam_map_vlp_1000.yaml;exec bash"'
gnome-terminal --window -e 'bash -c "ROS_NAMESPACE=tb_1 roslaunch turtlebot3_teleop turtlebot3_teleop_key.launch;exec bash"'
gnome-terminal --window -e 'bash -c "ROS_NAMESPACE=tb_3 roslaunch turtlebot3_teleop turtlebot3_teleop_key.launch;exec bash"'

